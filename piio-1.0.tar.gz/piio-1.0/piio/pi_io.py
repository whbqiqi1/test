import RPi.GPIO as GPIO

class pi_io_mode():
    def __init__(self,io_mode='we',data_mode=[7,11,13,15,16,18,22,26],adr_mode=[37,36,38,40],ds_mode=[29,31]):
        self.io_mode=io_mode
        self.data_mode=data_mode
        self.adr_mode=adr_mode
        self.ds_mode=ds_mode
        GPIO.setmode(GPIO.BOARD)
        GPIO.setwarnings(False)
        self.data_ioinit()
        self.adr__ioinit()
        self.ds__ioinit()

    def data_ioinit(self):
        if self.io_mode=='we':
            for i in self.data_mode:
                GPIO.setup(i, GPIO.OUT)
        if self.io_mode=='rd':
            for i in self.data_mode:
                GPIO.setup(i, GPIO.IN)

    def adr__ioinit(self):
        for i in self.adr_mode:
            GPIO.setup(i, GPIO.OUT)

    def ds__ioinit(self):
        for i in self.ds_mode:
            GPIO.setup(i, GPIO.OUT)

    def init_bus(self,adr,ds):
        for i in range(0,4):
            if (adr & 0x01) == 0x01:
                GPIO.output(self.adr_mode[i],GPIO.HIGH)
            else:
                GPIO.output(self.adr_mode[i],GPIO.LOW)

            adr=adr>>1
        for i in range(0, 2):
            if (ds & 0x01) == 0x01:
                GPIO.output(self.ds_mode[i], GPIO.HIGH)
            else:
                GPIO.output(self.ds_mode[i], GPIO.LOW)

            ds = ds >> 1
    def project_led(self,colour):
        for i in range(0, 3):
            if (colour & 0x01) == 0x01:
                GPIO.output(self.data_mode[i], GPIO.HIGH)
            else:
                GPIO.output(self.data_mode[i], GPIO.LOW)
            colour = colour >> 1


    def project_da(self,data):
        for i in range(0,8):
            if (data & 0x01) == 0x01:
                GPIO.output(self.data_mode[i], GPIO.HIGH)
            else:
                GPIO.output(self.data_mode[i], GPIO.LOW)
            data = data >> 1

    def project_da_rw(self):
        return (GPIO.input(self.data_mode[7]) << 7) + (GPIO.input(self.data_mode[6]) << 6) \
               + (GPIO.input(self.data_mode[5]) << 5) + (GPIO.input(self.data_mode[4]) << 4) \
               + (GPIO.input(self.data_mode[3]) << 3) + (GPIO.input(self.data_mode[2]) << 2) \
               + (GPIO.input(self.data_mode[1]) << 1) + GPIO.input(self.data_mode[0])




# coding:utf-8

#from setuptools import setup
# or
from distutils.core import setup  

setup(
        name='piio',     # 包名字
        version='1.0',   # 包版本
        description='This is a test of the setup',   # 简单描述
        author='whb',  # 作者
        author_email='376332425@qq.com',  # 作者邮箱
        url='https://www.jcs.com',      # 包的主页
        packages=['piio'],                 # 包
)



